import json
import os
import base64
from datetime import datetime, timezone

import boto3
import firebase_admin
from firebase_admin import credentials, db
from twilio.rest import Client

BEDROCK_REGION = os.environ.get("AWS_REGION", "ap-southeast-1")
bedrock_runtime = boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)

encoded_creds = os.environ.get("FIREBASE_CREDENTIALS_JSON_BASE64")
firebase_db_url = os.environ.get("FIREBASE_DATABASE_URL")

if not encoded_creds or not firebase_db_url:
    raise Exception("Missing FIREBASE_CREDENTIALS_JSON_BASE64 or FIREBASE_DATABASE_URL")

service_account_info = json.loads(base64.b64decode(encoded_creds))
cred = credentials.Certificate(service_account_info)
try:
    firebase_admin.get_app()
except ValueError:
    firebase_admin.initialize_app(cred, {"databaseURL": firebase_db_url})

ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
FROM_NUMBER = os.environ.get("TWILIO_FROM_NUMBER")  
TO_NUMBER = os.environ.get("TWILIO_TO_NUMBER")  

twilio_enabled = all([ACCOUNT_SID, AUTH_TOKEN, FROM_NUMBER, TO_NUMBER])
twilio_client = Client(ACCOUNT_SID, AUTH_TOKEN) if twilio_enabled else None

ALLOWED = {"HARVEST", "IRRIGATE", "APPLY FERTILISER", "MONITOR"}

def deterministic_actions(s):
    acts = set()
    try:
        if float(s.get("spectral_idx", -1)) >= 0.72 and float(s.get("rain_mm_next_24h", 0)) < 15:
            acts.add("HARVEST")
        if float(s.get("soil_moisture", 1)) < 0.18:
            acts.add("IRRIGATE")
        if float(s.get("soil_nutrient_index", 1)) < 0.4 or float(s.get("electrical_conductivity", 99)) < 1.2:
            acts.add("APPLY FERTILISER")
    except Exception:
        pass
    return list(acts or {"MONITOR"})

def construct_prompt(sensor_data):
    tree_id = sensor_data.get("tree_id", "N/A")

    def fmt(key, label, suffix=""):
        return f"- {label}: {sensor_data[key]}{suffix}\n" if key in sensor_data else ""

    data_summary = (
        f"Data for tree {tree_id}:\n"
        f"{fmt('spectral_idx', 'Drone Spectral Index')}"
        f"{fmt('soil_moisture', 'Soil Moisture')}"
        f"{fmt('electrical_conductivity', 'Electrical Conductivity', ' dS/m')}"
        f"{fmt('soil_nutrient_index', 'Soil Nutrient Index')}"
        f"{fmt('rain_mm_next_24h', 'Expected Rain (next 24 h)', ' mm')}"
    )

    prompt = f"""
You are *TanakPod AI*, a precision-farming assistant.
Analyse the following palm-tree sensor data and decide the appropriate farm action.

Decision rules:
- HARVEST if spectral_idx ≥ 0.72 and rain_mm_next_24h < 15
- IRRIGATE if soil_moisture < 0.18
- APPLY FERTILISER if soil_nutrient_index < 0.4 or electrical_conductivity < 1.2
- Otherwise MONITOR

Return only valid JSON, nothing else, exactly in this schema:
{{
  "tree_id": "{tree_id}",
  "actions": ["HARVEST" | "IRRIGATE" | "APPLY FERTILISER" | "MONITOR"],
  "rationale": "short one-sentence explanation"
}}

Sensor Data:
{data_summary}
"""
    return prompt

def call_bedrock(prompt_text):
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": [{"type": "text", "text": prompt_text}]}],
        "max_tokens": 300,
        "temperature": 0.1,
        "top_p": 0.9
    })
    resp = bedrock_runtime.invoke_model(
        body=body,
        modelId="anthropic.claude-3-haiku-20240307-v1:0",
        accept="application/json",
        contentType="application/json"
    )
    payload = json.loads(resp.get("body").read())
    if isinstance(payload.get("content"), list) and payload["content"]:
        for item in payload["content"]:
            if item.get("type") == "text" and "text" in item:
                return item["text"]
    if "output_text" in payload:
        return payload["output_text"]
    if "output" in payload:
        return payload["output"]["message"]["content"][0]["text"]
    raise KeyError("Unexpected Bedrock response structure")

def lambda_handler(event, context):
    print(f"[decision] Received event: {json.dumps(event)}")
    sensor_data = event if isinstance(event, dict) else {}

    prompt = construct_prompt(sensor_data)

    try:
        completion = call_bedrock(prompt)
    except Exception as e:
        print(f"⚠️ Bedrock call failed or parse error: {e}")
        completion = json.dumps({
            "tree_id": sensor_data.get("tree_id", "N/A"),
            "actions": deterministic_actions(sensor_data),
            "rationale": "Fallback due to model error"
        })

    try:
        decision = json.loads(completion)
    except json.JSONDecodeError:
        decision = {
            "tree_id": sensor_data.get("tree_id", "N/A"),
            "actions": deterministic_actions(sensor_data),
            "rationale": "Failed to parse AI output as JSON"
        }

    if not isinstance(decision.get("actions"), list):
        decision["actions"] = []
    decision["actions"] = [a for a in decision["actions"] if a in ALLOWED] or deterministic_actions(sensor_data)
    decision["tree_id"] = decision.get("tree_id") or sensor_data.get("tree_id", "N/A")
    decision["timestamp"] = datetime.now(timezone.utc).isoformat()

    print(f"[decision] Final decision: {json.dumps(decision)}")

    try:
        db.reference("decision_logs").push(decision)
        print("✅ Decision saved to Firebase.")
    except Exception as e:
        print(f"⚠️ Firebase write failed: {e}")

    if twilio_enabled:
        try:
            message_text = (
                f"🌾 *TanakPod AI Decision Alert*\n"
                f"Tree ID: {decision.get('tree_id','N/A')}\n"
                f"Action: {', '.join(decision.get('actions', []))}\n"
                f"Reason: {decision.get('rationale','N/A')}\n"
                f"🕒 {decision['timestamp']}"
            )
            print(f"[twilio] FROM={FROM_NUMBER} TO={TO_NUMBER} TEXT={message_text!r}")
            msg = twilio_client.messages.create(from_=FROM_NUMBER, to=TO_NUMBER, body=message_text)
            print(f"📲 WhatsApp sent. SID: {msg.sid}")
        except Exception as e:
            print(f"⚠️ WhatsApp send failed: {e}")
    else:
        print("ℹ️ Twilio not configured: set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER, TWILIO_TO_NUMBER.")

    return {"statusCode": 200, "body": json.dumps(decision)}
